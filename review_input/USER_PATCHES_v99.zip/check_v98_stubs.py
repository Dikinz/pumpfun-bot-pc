import sys,types,json,time,threading,http.server,http.client,importlib.util,os,tempfile,contextlib
from unittest import mock
from pathlib import Path

# ---- stubs for modules that exist only in the bot installation ----
for name in ['solders','solders.pubkey','solders.account','solders.instruction','solders.message','solders.transaction','solders.litesvm','solders.transaction_metadata','solders.clock','solders.rent']:
    sys.modules[name]=mock.MagicMock()
hashmod=types.ModuleType('solders.hash')
class Hash:
    @staticmethod
    def from_string(v):
        if not isinstance(v,str) or not 30<=len(v)<=50:raise ValueError('bad hash')
        return v
hashmod.Hash=Hash;sys.modules['solders.hash']=hashmod
cfg=types.ModuleType('config');cfg.QUOTE_RPC_URL='https://127.0.0.1:1/';sys.modules['config']=cfg
sys.modules['execution_verification']=mock.MagicMock()
class Row(dict):pass
class Trace:
    def __init__(s):s.row={}
    @contextlib.contextmanager
    def phase(s,n):yield
@contextlib.contextmanager
def request(method,n):yield Trace()
rt=types.ModuleType('rpc_timing');rt.request=request;rt.ACTIVE=None;sys.modules['rpc_timing']=rt
exc_log=[]
class Permit:
    def telemetry(s):return {}
@contextlib.contextmanager
def guard(url):
    try:yield Permit()
    except BaseException as e:exc_log.append(e);raise
rb=types.ModuleType('rpc_budget');rb.guard=guard;sys.modules['rpc_budget']=rb

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

# ---------------- keep-alive test ----------------
state=dict(connections=0,requests=0,mode='ok')
class H(http.server.BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def setup(s):
        state['connections']+=1;super().setup()
    def log_message(s,*a):pass
    def do_POST(s):
        n=int(s.headers['Content-Length']);body=json.loads(s.rfile.read(n));state['requests']+=1
        addrs=body['params'][0]
        if state['mode']=='429':
            s.send_response(429);s.send_header('Retry-After','7');s.send_header('Content-Length','0');s.end_headers();return
        if state['mode']=='rpcerror':payload={'jsonrpc':'2.0','id':1,'error':{'code':-32016,'message':'min context slot not reached'}}
        else:payload={'jsonrpc':'2.0','id':1,'result':{'context':{'slot':100+state['requests']},'value':[{'lamports':1,'data':['','base64']} for _ in addrs]}}
        data=json.dumps(payload).encode()
        s.send_response(200);s.send_header('Content-Type','application/json');s.send_header('Content-Length',str(len(data)))
        if state['mode']=='close':s.send_header('Connection','close')
        s.end_headers();s.wfile.write(data)
srv=http.server.ThreadingHTTPServer(('127.0.0.1',0),H);port=srv.server_address[1]
threading.Thread(target=srv.serve_forever,daemon=True).start()
http.client.HTTPSConnection=http.client.HTTPConnection # local plain-http stand-in for the TLS connection
cfg.QUOTE_RPC_URL='https://127.0.0.1:%d/'%port

ls=load('local_simulation.py','local_simulation_new')
def run(label,fn):
    try:r=fn();print('OK  ',label,r)
    except AssertionError as e:print('FAIL',label,e);raise
cfg.RPC_KEEPALIVE=True
def t_keepalive():
    state.update(connections=0,requests=0,mode='ok');ls._HTTP.clear()
    slots=[ls.read_accounts(['a','b','c'])['slot'] for _ in range(5)]
    assert state['connections']==1 and state['requests']==5,state
    assert slots==sorted(slots)
    return dict(connections=state['connections'],requests=state['requests'])
run('5 reads reuse one connection',t_keepalive)
def t_default_off():
    del cfg.RPC_KEEPALIVE
    assert not getattr(cfg,'RPC_KEEPALIVE',False);cfg.RPC_KEEPALIVE=True;return 'default (attribute absent) takes the urllib branch'
run('opt-in flag',t_default_off)
def t_429():
    state.update(mode='429');ls._HTTP.clear();exc_log.clear()
    try:ls.read_accounts(['a'])
    except Exception as e:
        import urllib.error
        assert isinstance(e,urllib.error.HTTPError) and e.code==429 and e.headers.get('Retry-After')=='7',repr(e)
        assert exc_log and exc_log[-1] is e
        assert not ls._HTTP
        return 'HTTPError code=%s retry-after=%s, connection dropped'%(e.code,e.headers.get('Retry-After'))
    raise AssertionError('no exception')
run('429 keeps code/headers for the budget',t_429)
def t_rpc_error():
    state.update(mode='rpcerror',connections=0,requests=0);ls._HTTP.clear()
    try:ls.read_accounts(['a'])
    except ls.LabError as e:
        assert str(e)=='RPC_ERROR_-32016';assert ls._HTTP # connection stays usable after a JSON-RPC error
        state['mode']='ok';ls.read_accounts(['a']);assert state['connections']==1
        return str(e)+'; next call reused the connection'
    raise AssertionError
run('JSON-RPC error',t_rpc_error)
def t_close():
    state.update(mode='close',connections=0,requests=0);ls._HTTP.clear()
    ls.read_accounts(['a']);assert not ls._HTTP
    ls.read_accounts(['a']);assert state['connections']==2
    return 'Connection: close respected, reconnects'
run('server closes',t_close)
def t_stale():
    state.update(mode='ok',connections=0,requests=0);ls._HTTP.clear()
    ls.read_accounts(['a']);conn=list(ls._HTTP.values())[0];conn.sock.close() # simulate dead socket
    try:ls.read_accounts(['a']);return 'unexpectedly ok'
    except Exception as e:
        assert not ls._HTTP
        state['mode']='ok';ls.read_accounts(['a']);return 'dead socket -> %s propagated (no silent retry), next call reconnects'%type(e).__name__
run('stale connection: no hidden retry',t_stale)

# ---------------- genesis cache test ----------------
pc=load('program_cache.py','program_cache_new')
calls=[]
eq=types.ModuleType('exit_quotes')
HASH='5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d'
def request_json(url,label,payload):calls.append(url);return {'result':HASH}
eq.request_json=request_json;sys.modules['exit_quotes']=eq
tmp=Path(tempfile.mkdtemp())
class Lab:
    class config:QUOTE_RPC_URL='https://rpc.test/a';GENESIS_CACHE_PATH=tmp/'g.json'
lab=Lab()
def g1():
    calls.clear();[pc.genesis(lab) for _ in range(3)];assert len(calls)==3;return 'ttl absent: 3 live calls, no file=%s'%(not (tmp/'g.json').exists())
run('default unchanged',g1)
Lab.config.GENESIS_CACHE_TTL_S=3600
def g2():
    calls.clear();v=[pc.genesis(lab) for _ in range(4)];assert len(calls)==1 and set(v)=={HASH};return 'ttl on: 1 live call for 4'
run('cached across calls',g2)
def g3():
    calls.clear();Lab.config.QUOTE_RPC_URL='https://rpc.test/b';pc.genesis(lab);pc.genesis(lab);assert len(calls)==1
    Lab.config.QUOTE_RPC_URL='https://rpc.test/a';pc.genesis(lab);assert len(calls)==1;return 'keyed by endpoint URL'
run('per-endpoint key',g3)
def g4():
    calls.clear();d=json.loads((tmp/'g.json').read_text());k=next(iter(d));d[k]['ts']=time.time()-7200;(tmp/'g.json').write_text(json.dumps(d))
    Lab.config.QUOTE_RPC_URL='https://rpc.test/a';pc.genesis(lab);return 'expired entry refetched: calls=%d'%len(calls)
run('ttl expiry',g4)
def g5():
    (tmp/'g.json').write_text('{not json');calls.clear();pc.genesis(lab);assert len(calls)==1;pc.genesis(lab);assert len(calls)==1;return 'corrupt file ignored and rewritten'
run('corrupt cache file',g5)
def g6():
    (tmp/'g.json').write_text(json.dumps({pc._genesis_key('https://rpc.test/a'):dict(value='bad',ts=time.time())}));calls.clear();pc.genesis(lab);assert len(calls)==1;return 'invalid cached value rejected'
run('invalid value',g6)
def g7():
    (tmp/'g.json').write_text(json.dumps({pc._genesis_key('https://rpc.test/a'):dict(value=HASH,ts=time.time()+10**6)}));calls.clear();pc.genesis(lab);assert len(calls)==1;return 'future timestamp rejected'
run('clock skew',g7)
def g8():
    Lab.config.GENESIS_CACHE_PATH=Path('/proc/nonexistent/x.json');calls.clear();v=pc.genesis(lab);assert v==HASH;Lab.config.GENESIS_CACHE_PATH=tmp/'g.json';return 'unwritable path is not an error'
run('write failure',g8)
def g9():
    Lab.config.GENESIS_CACHE_PATH=tmp/'g2.json';errs=[]
    def w(i):
        try:
            for j in range(30):pc._genesis_store(tmp/'g2.json','https://rpc.test/%d'%(i%3),HASH)
        except Exception as e:errs.append(e)
    ts=[threading.Thread(target=w,args=(i,)) for i in range(6)];[t.start() for t in ts];[t.join() for t in ts]
    d=json.loads((tmp/'g2.json').read_text());assert not errs and len(d)==3;left=list(tmp.glob('*.tmp'));assert not left,left
    return 'concurrent writers: file valid, no leftovers'
run('concurrent store',g9)
def g10():
    def bad(url,label,payload):return {'result':'x'}
    eq.request_json=bad;Lab.config.GENESIS_CACHE_PATH=tmp/'g3.json'
    try:pc.genesis(lab)
    except pc.CacheError as e:
        assert not (tmp/'g3.json').exists();return str(e)+' and nothing cached'
    raise AssertionError
run('unverified live value not cached',g10)
print('ALL PASSED')
