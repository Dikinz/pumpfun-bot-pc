import importlib.util
import importlib,os,sys,time,json,tempfile,threading
from pathlib import Path
def load(name):
    sys.modules.pop('rpcmod',None)
    spec=importlib.util.spec_from_file_location('rpcmod',name);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def winerr(path=None):
    e=PermissionError(13,'denied');e.winerror=5;return e

def scenario_unlink_fails(m,label):
    root=Path(tempfile.mkdtemp())
    b=m.Budget(root,rate=1000.,slots=2,wait=.75)
    real=Path.unlink
    fail={'on':True}
    def bad(self,*a,**k):
        if fail['on'] and self.suffix=='.json' and self.parent.name=='outcomes':raise winerr()
        return real(self,*a,**k)
    Path.unlink=bad
    try:
        results=[]
        for i in range(3):
            try:
                with b.request('https://example.test/rpc'):pass
                results.append('ok')
            except Exception as e:results.append(type(e).__name__+':'+str(e))
        blocked=b.failed.exists()
        left=len(list((root/'outcomes').glob('*.json')))
        fail['on']=False
        try:
            with b.request('https://example.test/rpc'):pass
            after='ok'
        except Exception as e:after=type(e).__name__+':'+str(e)
        left2=len(list((root/'outcomes').glob('*.json')))
    finally:Path.unlink=real
    print(f'[{label}] unlink-fails: results={results} blocked={blocked} leftover_files={left} -> after unlink works: {after}, leftover={left2}')
    return blocked

def scenario_race_gone(m,label):
    # unlink raises access denied because another process already deleted (delete-pending) -> file is gone
    root=Path(tempfile.mkdtemp());b=m.Budget(root,rate=1000.,slots=2,wait=.75)
    real=Path.unlink
    def racey(self,*a,**k):
        if self.suffix=='.json' and self.parent.name=='outcomes':
            real(self,*a,**k);raise winerr()
        return real(self,*a,**k)
    Path.unlink=racey
    try:
        with b.request('https://example.test/rpc'):pass
        r='ok'
    except Exception as e:r=type(e).__name__
    finally:Path.unlink=real
    print(f'[{label}] race(file already gone): result={r} blocked={b.failed.exists()}')

def scenario_marker(m,label):
    root=Path(tempfile.mkdtemp());b=m.Budget(root,rate=1000.,slots=2,wait=.75)
    if hasattr(m.Budget,'RECOVER_AFTER_SECONDS'):b.RECOVER_AFTER_SECONDS=.2
    with b.request('https://example.test/rpc'):pass
    try:b.block(winerr(),durable=True)
    except TypeError:b.block(winerr())
    time.sleep(.3)
    try:
        with b.request('https://example.test/rpc'):pass
        r1='ok'
    except Exception as e:r1=str(e)
    try:b.block(m.Unavailable('RPC_OUTCOME_INVALID'),stage='X',durable=True)
    except TypeError:b.block(m.Unavailable('RPC_OUTCOME_INVALID'),stage='X')
    time.sleep(.3)
    try:
        with b.request('https://example.test/rpc'):pass
        r2='ok'
    except Exception as e:r2=str(e)
    print(f'[{label}] transient marker -> {r1}; invalid-outcome marker -> {r2}; marker_exists={b.failed.exists()}')

def scenario_tmp(m,label):
    root=Path(tempfile.mkdtemp());b=m.Budget(root,rate=1000.,slots=2,wait=.3)
    (root/'outcomes').mkdir();t=root/'outcomes'/'dead.tmp';t.write_text('{}')
    old=time.time()-60;os.utime(t,(old,old))
    try:
        with b.request('https://example.test/rpc'):pass
        r='ok'
    except Exception as e:r=type(e).__name__+':'+str(e)
    print(f'[{label}] stale .tmp: {r}; tmp_exists={t.exists()}')

def scenario_threads(m,label):
    root=Path(tempfile.mkdtemp())
    errs=[];
    def work():
        b=m.Budget(root,rate=1000.,slots=4,wait=.75)
        for _ in range(60):
            try:
                with b.request('https://example.test/rpc'):pass
            except m.Deferred:pass
            except Exception as e:errs.append(type(e).__name__+':'+str(e));return
    ts=[threading.Thread(target=work) for _ in range(6)]
    [t.start() for t in ts];[t.join() for t in ts]
    print(f'[{label}] 6 threads x60: errors={errs[:3]} blocked={(root/"control_failed.json").exists()} leftover={len(list((root/"outcomes").glob("*")))}')

for name,label in (('rpc_budget_orig.py','ORIG'),('rpc_budget.py','PATCHED')):
    m=load(name)
    scenario_unlink_fails(m,label);scenario_race_gone(m,label);scenario_marker(m,label);scenario_tmp(m,label);scenario_threads(m,label)
